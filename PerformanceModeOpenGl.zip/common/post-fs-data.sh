#!/system/bin/sh
MODDIR=${0%/*}

#function(s)
BTFST() {
    for i in /sys/block/*/queue/read_ahead_kb
    do
    echo 2048 > $i
    done
    
    for i in /sys/block/*/queue/nr_requests
    do
    echo 512 > $i
    done
}

#main program
BTFST

MODDIR=${0%/*}

for i in /sys/block/*/queue/iostats
do
echo 0 > $i
done

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 8.8.8.8\nnameserver 1.1.1.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi

# I Love Miku and Kaguya-chann 
# Auothor@ZxyonQiy

resetprop -n "ro.build.draw_buffers" "4"
resetprop -n "ro.build.array_texture_layers" "2048"
resetprop -n "ro.build.3d_texture_size" "2048"
resetprop -n "ro.build.elements_vertices" "1048575"
resetprop -n "ro.build.element_index" "4294967295"
resetprop -n "ro.build.elements_indices" "150000"
resetprop -n "ro.build.fragment_input_components" "64"
resetprop -n "ro.build.fragment_uniform_blocks" "12"
resetprop -n "ro.build.fragment_uniform_vectors" "224"
resetprop -n "ro.build.fragment_uniform_components" "896"
resetprop -n "ro.build.program_texel_offset" "7"
resetprop -n "ro.build.renderbuffer.size" "16384"
resetprop -n "ro.build._samples" "4"
resetprop -n "ro.build.server_wait_timeout" "-1"
resetprop -n "ro.build.transform_feedback_separate_attribs" "4"
resetprop -n "ro.build.uniform_block_size" "16384"
resetprop -n "ro.build.uniform_buffer_bindings" "24"
resetprop -n "ro.build.varying_components" "60"
resetprop -n "ro.build.varying_vectors" "15"
resetprop -n "ro.build.vertex_attribs" "16"
resetprop -n "ro.build.vertex_output_components" "64"
resetprop -n "ro.build.vertex_texture_image_units" "16"
resetprop -n "ro.build.vertex_uniform_blocks" "12"
resetprop -n "ro.build.vertex_uniform_vectors" "512"
resetprop -n "ro.build.vertex_uniform_components" "2048"
resetprop -n "ro.build..texture_image_units" "16"

find /sys/devices/system/cpu -maxdepth 1 -name 'cpu?' | while IFS= read -r cpu; do
  max_freq=$(read_file_unlock "$cpu/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 1)
  write_file_lock "$cpu/cpufreq/scaling_min_freq" "$max_freq"
  write_file_lock "$cpu/cpufreq/scaling_max_freq" "$max_freq"
done

max_freq=$(read_file_unlock "/sys/class/kgsl/kgsl-3d0/freq_table_mhz" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 1)
write_file_lock "/sys/class/kgsl/kgsl-3d0/min_clock_mhz" "$max_freq"
write_file_lock "/sys/class/kgsl/kgsl-3d0/max_clock_mhz" "$max_freq"
write_file_lock "/sys/class/kgsl/kgsl-3d0/throttling" "0"
find /sys/kernel/debug/kgsl/kgsl-3d0/ -name '*log*' | while IFS= read -r log; do
wr
write_file_lock "$log" "0"
done


