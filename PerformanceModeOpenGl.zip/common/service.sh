#!/system/bin/sh

#functions
write() {
	[[ ! -f "$1" ]] && return 1
	chmod +w "$1" 2> /dev/null
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 20

while [ -z "$(resetprop sys.boot_completed)" ]; do
    sleep 5
done

# CpuBoost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
 
# Gpu Boost
echo "0:0 4:0" > /sys/module/gpu_boost/parameters/topkek_boost_freq
echo '100' > /sys/module/gpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/gpu_boost/parameters/input_boost_freq
echo '100' > /sys/module/gpu_boost/parameters/input_boost_ms

# Sync before execute to avoid crashes
sync

HRTICK() { write /sys/kernel/debug/sched_features HRTICK }

DISABLE_DEBUGGING() {
    for i in /sys/block/*/queue/iostats
    do
    echo 0 > $i
    done 
    
    for i in /sys/module/*/parameters/debug_mask
    do 
    echo 0 > $i
    done
    
    for i in /sys/module/*/parameters/debug_level 
    do 
    echo 0 > $i
    done
    
    if [ $(getprop init.svc.logd) = running ]; then
    stop logd
    fi 
    
    if [ $(getprop init.svc.statsd) = running ]; then
    stop statsd
    fi 
    
    if [ $(getprop init.svc.traced) = running ]; then
    stop traced
    fi
    
    write /proc/sys/fs/dir-notify-enable 0
    
    write /proc/sys/kernel/hung_task_timeout_secs 0
    
    write /proc/sys/vm/stat_interval 10
    
    write /sys/module/printk/parameters/console_suspend Y
    
    write /proc/sys/kernel/printk_devkmsg off
    
    write /proc/sys/kernel/printk 0 0 0 0
    
    write /sys/module/printk/parameters/cpu N
    
    write /sys/kernel/printk_mode/printk_mode 0
    
    write /sys/module/printk/parameters/ignore_loglevel Y
    
    write /sys/module/printk/parameters/pid N
    
    write /sys/module/printk/parameters/time N
    
    write /sys/kernel/debug/debug_enabled N
    
    write /proc/sys/kernel/sched_schedstats 0
    
    write /proc/sys/vm/oom_dump_tasks 0
    
    write /proc/sys/vm/block_dump 0
    
    write /sys/module/subsystem_restart/parameters/enable_ramdumps 0

    write /sys/module/rmnet_data/parameters/rmnet_data_log_level 0
    
    write /sys/kernel/tracing/tracing_on 0
    
    write /sys/kernel/debug/tracing/tracing_on 0
    
    write /proc/sys/kernel/compat-log 0
    
    write /sys/module/logger/parameters/log_enabled 0
    
    write /proc/sys/debug/exception-trace 0
    
    write /sys/module/debug/parameters/enable_event_log 0
    
    write /sys/module/logger/parameters/enabled 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv 0
       
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr 0
    
    write /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem 0
    
    write /sys/module/mali/parameters/mali_debug_level 0
    
    write /sys/module/ext4/parameters/mballoc_debug 0
    
    write /sys/module/rpm_smd/parameters/debug_mask 0
    
    write /sys/module/msm_show_resume_irq/parameters/debug_mask 0
    write /sys/module/rmnet_data/parameters/rmnet_data_log_level 0
    write /sys/module/ip6_tunnel/parameters/log_ecn_error N
    
    write /sys/module/mmc_core/parameters/use_spi_crc 0
}

BTFST() {
    #reset read ahead and nr requests to default after boot
    for i in /sys/block/*/queue/read_ahead_kb
    do
    echo 128 > $i
    done
    
    for i in /sys/block/*/queue/nr_requests
    do
    echo 64 > $i
    done
}

    sleep 5

#main program
HRTICK
DISABLE_DEBUGGING
BTFST

MODDIR=${0%/*}

if [ $(getprop init.svc.logd) = running ]; then
stop logd
fi 

if [ $(getprop init.svc.statsd) = running ]; then
stop statsd
fi 

if [ $(getprop init.svc.traced) = running ]; then
stop traced
fi

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 1 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

sync && echo 3 > /proc/sys/vm/drop_caches

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53

echo "NO_GENTLE_FAIR_SLEEPERS:1" > /sys/kernel/debug/sched_features
echo "START_DEBIT:1" > /sys/kernel/debug/sched_features
echo "NEXT_BUDDY:1" > /sys/kernel/debug/sched_features
echo "LAST_BUDDY:1" > /sys/kernel/debug/sched_features
echo "STRICT_SKIP_BUDDY:1" > /sys/kernel/debug/sched_features
echo "CACHE_HOT_BUDDY:1" > /sys/kernel/debug/sched_features
echo "WAKEUP_PREEMPTION:1" > /sys/kernel/debug/sched_features
echo "NO_HRTICK:1" > /sys/kernel/debug/sched_features
echo "NO_DOUBLE_TICK:1" > /sys/kernel/debug/sched_features
echo "LB_BIAS:1" > /sys/kernel/debug/sched_features
echo "NONTASK_CAPACITY:1" > /sys/kernel/debug/sched_features
echo "NO_TTWU_QUEUE:1" > /sys/kernel/debug/sched_features
echo "NO_SIS_AVG_CPU:1" > /sys/kernel/debug/sched_features
echo "RT_PUSH_IPI:1" > /sys/kernel/debug/sched_features
echo "NO_FORCE_SD_OVERLAP:1" > /sys/kernel/debug/sched_features
echo "NO_RT_RUNTIME_SHARE:1" > /sys/kernel/debug/sched_features
echo "NO_LB_MIN:1" > /sys/kernel/debug/sched_features
echo "ATTACH_AGE_LOAD:1" > /sys/kernel/debug/sched_features
echo "ENERGY_AWARE:1" > /sys/kernel/debug/sched_features
echo "NO_MIN_CAPACITY_CAPPING:1" > /sys/kernel/debug/sched_features
echo "NO_FBT_STRICT_ORDER:1" > /sys/kernel/debug/sched_features
echo "EAS_USE_NEED_IDLE:1" > /sys/kernel/debug/sched_features

write "$GPUDIR/gpu_min_clock" "$max_clock_gpu"
write "$GPUDIR/gpu_max_clock" "$max_clock_gpu"
write "$KGSLDIR/kgsl-3d0/min_clock_mhz" "$max_clock_kgsl"
write "$KGSLDIR/kgsl-3d0/max_clock_mhz" "$max_clock_kgsl"
write "$KGSLDIR/kgsl-3d0/throttling" "0"

echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '6' > /proc/sys/net/ipv4/tcp_probe_threshold;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '5' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '80' > /proc/sys/net/ipv4/tcp_pacing_ca_ratio;
echo '150' > /proc/sys/net/ipv4/tcp_pacing_ss_ratio;
echo '400' > /proc/sys/net/ipv4/tcp_probe_interval;
echo "404480" > /proc/sys/net/core/wmem_max;
echo "404480" > /proc/sys/net/core/rmem_max;
echo "256960" > /proc/sys/net/core/rmem_default;
echo "256960" > /proc/sys/net/core/wmem_default;
echo "4096,16384,404480" > /proc/sys/net/ipv4/tcp_wmem;
echo "4096,87380,404480" > /proc/sys/net/ipv4/tcp_rmem; 
echo '404480 404480 404480' > /proc/sys/net/ipv4/tcp_mem;
echo 'Y' > /sys/module/module/parameters/lock_wlanmodule;
chown wifi wifi /sys/module/wlan/parameters/fwpath;
cat /proc/sys/net/ipv4/tcp_allowed_congestion_control;
echo 'bbr westwood cubic reno' > /proc/sys/net/ipv4/tcp_allowed_congestion_control;
cat /proc/sys/net/ipv4/tcp_available_congestion_control;
echo 'bbr westwood cubic reno bic cdg dctcp hybla htcp vegas veno lp yeah illinois' > /proc/sys/net/ipv4/tcp_available_congestion_control;
cat /proc/sys/net/ipv4/tcp_congestion_control;
sudo sysctl -w net.ipv4.tcp_congestion_control=bbr
sudo sysctl -w net/ipv4/tcp_congestion_control=bbr
echo 'bbr' > /proc/sys/net/ipv4/tcp_congestion_control;
restorecon -R /proc/sys/net/ipv4/tcp_congestion_control;

chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id

chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq

chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity

sleep 60
properties=(
"debug.cpurend.vsync false"
"ro.kernel.checkjni 0"
"ro.kernel.android.checkjni 0"
"ro.surfaceflinger.hardware 1"
"persist.hwc.mdpcomp 1"
"debug.performance.tuning 1"
"ro.config.av_sync_smooth 1"
"crypto.accelerator aes"
"persist.sys.gpu.vr 1"
"av.enable.isp true"
"dalvik.vm.dex2oat-filter speed"
"dalvik.vm.dex2oat-threads 8"
"persist.sys.NV_FPSLIMIT 144"
"persist.sys.NV_POWERMODE 1"
"persist.sys.NV_PROFVER 15"
"persist.sys.NV_STEREOCTRL 0"
"persist.sys.NV_STEREOSEPCHG 0"
"persist.sys.NV_STEREOSEP 20"
"ro.hwui.disable_scissor_opt false"
"ro.zygote.disable_gl_preload true"
"persist.sys.purgeable_assets 1"
"ro.config.zram.enabled false"
"hwui.render_dirty_regions false"
"debug.hwui.use_buffer_age true"
"persist.sys.ui.accelerate 1"
"persist.service.trim.enable 1"
"ro.ril.hwuserid true"
"ro.product.gpu.driver 1"
"ro.config.hw_quickpoweron true"
"persist.service.lgospd.enable 0"
"persist.service.pcsync.enable 0"
"debug.atrace.tags.enableflags 0"
"profiler.force_disable_ulog true"
"profiler.force_disable_err_rpt true"
"profiler.force_disable_ulog 1"
"profiler.force_disable_err_rpt 1"
"debug.composition.type gpu"
"debug.composition.type c2d"
"debug.composition.type opengl"
"debug.hwui.renderer opengl"
"ro.surface_flinger.max_frame_buffer_acquired_buffers 3"
"ro.com.google.locationfeatures 0"
"ro.com.google.networklocation 0"
"profiler.debugmonitor false"
"profiler.launch false"
"profiler.hung.dumpdobugreport false"
"logcat.live disable"
"debugtool.anrhistory 0"
"ro.config.htc.nocheckin 1"
"ro.config.nocheckin 1"
"debug.als.logs 0"
"debug.svi.logs 0"
"debug.mdpcomp.logs 0"
"debug.egl.force_msaa 0"
"debug.egl.force_fxaa 0"
"debug.egl.force_taa 0"
"debug.egl.force_ssaa 0"
"debug.egl.force_smaa 0"
"ro.logd.size 0"
"ro.logd.size.stats 0"
"log.tag.stats_log 0"
"logd.logpersistd.enable false"
"persist.vendor.verbose_logging_enabled false"
"persist.debug.trace 0"
"debug.atrace.tags.enableflags 0"
"persist.sys.loglevel 0"
"sys.log.app 0"
"persist.traced.enable 0"
"logd.statistics 0"
"persist.sample.eyetracking.log 0"
"debug.atrace.tags.enableflags 0"
"profiler.hung.dumpdobugreport false"
"touch.pressure.scale 0.0001"
"persist.sys.composition.type c2d"
"persist.sys.composition.type gpu"
"touch.orientationAware 0"
"persist.sys.ui.hw 1"
"touch.size.calibration geometric"
"touch.size.scale 1"
"touch.size.bias 0"
"touch.size.isSummed 0"
"persist.device_config.runtime_native.usap_pool_enabled true"
"touch.orientation.calibration interpolated" 
"touch.distance.calibration area"
"touch.distance.scale 0"
"touch.coverage.calibration box"
"dalvik.vm.image-dex2oat-cpu-set 0,1,2,3,4,5,6,7"
"dalvik.vm.boot-dex2oat-threads 4"
"dalvik.vm.boot-dex2oat-cpu-set 0,1,2,3,4,5,6,7"
"dalvik.vm.dex2oat-cpu-set 0,1,2,3,4,5,6,7"
"dalvik.vm.dex2oat-gpu-set 0,1,2,3,4,5,6,7"
"touch.pressure.scale 0"
"touch.gestureMode spots"
"MultitouchMinDistance 1px"
"MultitouchSettleInterval 0.1ms"
"SurfaceOrientation 0"
"TapInterval 0.1ms"
"TapDragInterval 0.1ms"
"QuietInterval 0.1ms"
"MovementSpeedRatio 0.8"
"TapSlop 1px"
"persist.dev.pm.dyn_samplingrate 1"
"touch.pressure.calibration amplitude"
"windowsmgr.max_events_per_sec 60"
"view.scroll_friction 0"
"ro.min_pointer_dur 8"
"touch.deviceType touchScreen"
"debug.egl.hw 1"
"debug.sf.hw 1"
"video.accelerate.hw 1"
"view.scroll_friction 0"
"debug.gr.swapinterval 0"
"debug.egl.swapinterval -0"
"pm.dexopt.bg-dexopt speed-profile"
"pm.dexopt.shared speed"
"net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960"
"net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960"
"net.tcp.buffersize.lte 524288,1048576,2097152,524288,1048576,2097152"
"net.tcp.buffersize.umts 4096,87380,256960,4096,16384,256960"
"net.tcp.buffersize.evdo 4096,87380,563200,4096,16384,262144"
"net.tcp.buffersize.evdo_b 6144,262144,1048576,6144,262144,1048576"
"net.tcp.buffersize.gprs 4096,87380,256960,4096,16384,256960"
"net.tcp.buffersize.edge 4096,87380,256960,4096,16384,256960"
"net.tcp.buffersize.hsdpa 6144,87380,1048576,6144,87380,1048576"
"net.tcp.buffersize.hspa 6144,87380,524288,6144,16384,262144"
"net.tcp.buffersize.hspap 4096,87380,1220608,4096,16384,393216"
"net.tcp.buffersize.hsupa 4096,87380,704512,4096,16384,262144"
"ro.ril.hsxpa 2"
"ro.ril.hspa 2"
"ro.ril.lte 2"
"ro.ril.ltea 2"
"ro.ril.hep 0"
"ro.ril.def.agps.mode 2"
"ro.ril.enable.3g.prefix 1"
"ro.ril.enable.4g.prefix 1'
"ro.ril.htcmaskw1.bitmask 4294967295"
"ro.ril.htcmaskw1 14449"
"ro.ril.enable.dtm 1"
"ro.ril.hspaclass 15"
"ro.ril.lteclass 15"
"ro.ril.gprsclass 15"
"ro.ril.hsupa.category 10"
"ro.ril.hsdpa.category 30"
"ro.ril.lte.category 10"
"ro.ril.ltea.category 30"
"ro.ril.enable.a51 1"
"ro.ril.enable.a52 1"
"ro.ril.enable.a53 1"
"ro.ril.enable.a54 1"
"ro.ril.enable.a55 1"
"net.core.wmem_max 1048576"
"net.core.rmem_max 1048576"
"net.core.rmem_default 262144"
"net.core.wmem_default 262144"
"net.core.optmem_max 20480"
"net.unix.max_dgram_qlen 50"
"net.ipv4.tcp_ecn 0"
"net.ipv4.route.flush 1"
"net.ipv4.tcp_rfc1337 1"
"net.ipv4.ip_no_pmtu_disc 0"
"net.ipv4.tcp_sack 1"
"net.ipv4.tcp_fack 1"
"net.ipv4.tcp_window_scaling 1"
"net.ipv4.tcp_timestamps 1"
"net.ipv4.tcp_rmem 4096 39000 187000"
"net.ipv4.tcp_wmem 4096 39000 187000"
"net.ipv4.tcp_mem 187000 187000 187000"
"net.ipv4.tcp_no_metrics_save 1"
"net.ipv4.tcp_moderate_rcvbuf 1"
"net.ipv6.tcp_ecn 0"
"net.ipv6.route.flush 1"
"net.ipv6.tcp_rfc1337 1"
"net.ipv6.ip_no_pmtu_disc 0"
"net.ipv6.tcp_sack 1"
"net.ipv6.tcp_fack 1"
"net.ipv6.tcp_window_scaling 1"
"net.ipv6.tcp_timestamps 1"
"net.ipv6.tcp_rmem 4096 39000 187000"
"net.ipv6.tcp_wmem 4096 39000 187000"
"net.ipv6.tcp_mem 187000 187000 187000"
"net.ipv6.tcp_no_metrics_save 1"
"net.ipv6.tcp_moderate_rcvbuf 1"
"net.tethering.noprovisioning true"
"persist.cust.tel.eons 1"
"ro.config.hw_fast_dormancy 1"
"ro.config.combined_signal true"
"telephony.lteOnCdmaDevice 1"
"ro.telephony.default_network 33,33"
"ro.ril.enable.amr.wideband 1"
"persist.bt.enableAptXHD true"
"persist.service.btui.use_aptx 1"
"persist.vendor.bt.a2dp_offload_cap sbc-aptx-aptxtws-aptxhd-aptxadaptive-aac-ldac"
"persist.bluetooth.a2dp_offload.cap sbc-aptx-aptxtws-aptxhd-aptxadaptive-aac-ldac"
"persist.vendor.btstack.a2dp_offload_cap sbc-aptx-aptxtws-aptxhd-aptxadaptive-aac-ldac"
"persist.vendor.qcom.bluetooth.a2dp_offload_cap sbc-aptx-aptxtws-aptxhd-aptxadaptive-aac-ldac"
"persist.bluetooth.disableabsvol true"
"persist.vendor.btstack.enable.splita2dp true"
"persist.vendor.btstack.aac_frm_ctl.enabled true"
"persist.vendor.btstack.enable.twsplus true"
"persist.vendor.btstack.connect.peer_earbud true"
"persist.vendor.btstack.enable.twsplussho true"
"ro.bluetooth.emb_wp_mode false"
"ro.bluetooth.wipower false"
"ro.bluetooth.remote.autoconnect true"
"ro.bluetooth.request.master true"
"ro.vendor.bluetooth.wipower false"
"persist.vendor.qcom.bluetooth.aac_frm_ctl.enabled true"
"persist.vendor.qcom.bluetooth.twsp_state.enabled false"
"persist.vendor.qcom.bluetooth.enable.splita2dp true
"ro.gsm.2nd_data_retry_config max/_retries 3, 2000, 2000, 2000"
"persist.telephony.support.ipv6 1"
"persist.telephony.support.ipv4 1"
)

for prop in "${properties[@]}"; do
  resetprop -n $prop
done

#Fstrim
fstrim -v /metadata
fstrim -v /odm
fstrim -v /system_ext
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload

for queue in /sys/block/mmcblk*/queue; do
echo "0" > $queue/add_random
echo "0" > $queue/iostats
done

for governor in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    echo performance > $governor
done

# Exit
exit 0